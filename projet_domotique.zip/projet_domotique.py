from tkinter import *  # Importation de tous les éléments de la bibliothèque tkinter
from tkinter import messagebox  # Pour les boîtes de dialogue
import datetime  # Pour obtenir l'heure actuelle
import threading  # Pour lancer une tâche en parallèle (ex. : vérification heure)
import time  # Pour temporiser (attente dans les threads)

# Classe représentant une pièce de la maison
class Piece:
    def __init__(self, parent, nom):
        self.nom = nom  # Nom de la pièce
        self.frame = LabelFrame(parent, text=nom, padx=10, pady=10)  # Cadre pour la pièce avec titre
        self.frame.pack(padx=10, pady=10, fill="x")  # Placement dans la fenêtre

        # Gestion de la lumière
        self.etat_lumiere = StringVar()  # Variable liée à l'affichage du statut de la lumière
        self.etat_lumiere.set("Lumière : OFF")  # Par défaut : lumière éteinte

        Label(self.frame, textvariable=self.etat_lumiere).grid(row=0, column=1, padx=5, pady=5)  # Affiche l'état
        Button(self.frame, text="Allumer", command=self.allumer).grid(row=1, column=0, padx=5)  # Bouton pour allumer
        Button(self.frame, text="Éteindre", command=self.eteindre).grid(row=1, column=2, padx=5)  # Bouton pour éteindre

        # Contrôle de la température
        Label(self.frame, text="Température").grid(row=2, column=1)  # Libellé
        self.label_temp = Label(self.frame, text="20°C")  # Valeur par défaut
        self.label_temp.grid(row=3, column=1)
        self.scale_temp = Scale(self.frame, from_=10, to=30, orient=HORIZONTAL, command=self.maj_temp)  # Curseur
        self.scale_temp.set(20)
        self.scale_temp.grid(row=4, column=1, pady=5)

    # Méthode pour allumer la lumière
    def allumer(self):
        self.etat_lumiere.set("Lumière : ON")

    # Méthode pour éteindre la lumière
    def eteindre(self):
        self.etat_lumiere.set("Lumière : OFF")

    # Mise à jour de la température
    def maj_temp(self, valeur):
        self.label_temp.config(text=f"{valeur}°C")

    # Tout éteindre et remettre la température à 20°C
    def eteindre_tout(self):
        self.eteindre()
        self.scale_temp.set(20)
        self.maj_temp("20")

# Classe principale de l'application
class ApplicationDomotique:
    def __init__(self, root):
        self.root = root  # Référence à la fenêtre principale
        root.title("Application Domotique - Licence 2 MIASHS")  # Titre de la fenêtre
        root.geometry("600x1000")  # Dimensions de la fenêtre

        # Titre principal
        Label(root, text="Contrôle intelligent de la maison", font=("Helvetica", 18, "bold"), fg="blue").pack(pady=10)
        self.label_heure = Label(root, text="", font=("Helvetica", 10))  # Label vide pour afficher l'heure
        self.label_heure.pack(pady=5)
        self.mettre_a_jour_heure()  # Lancement de la mise à jour de l'heure en continu

        # Liste des pièces
        self.pieces = ["Salon", "Cuisine", "Chambre 1", "Chambre 2", "Chambre 3", "Salle de bain", "Salle de cinéma"]
        self.objets_pieces = []  # Liste pour stocker les objets Piece

        # Création des objets Piece
        for nom in self.pieces:
            p = Piece(root, nom)
            self.objets_pieces.append(p)

        # Boutons d'actions globales
        Button(root, text="Tout éteindre", command=self.tout_eteindre, bg="orange").pack(pady=10)
        Button(root, text="Afficher état général", command=self.afficher_etat, bg="lightblue").pack(pady=5)

        # Boutons spécifiques domotiques
        Button(root, text="Déclencher alarme intrusion", command=self.declencher_alarme_intrus, bg="red", fg="white").pack(pady=5)
        Button(root, text="Déclencher alarme incendie", command=self.declencher_alarme_incendie, bg="red", fg="white").pack(pady=5)
        Button(root, text="Allumer Smart TV", command=self.smart_tv, bg="green", fg="white").pack(pady=5)

        # Bouton pour quitter l'application
        Button(root, text="Quitter", command=root.quit, bg="black", fg="white").pack(pady=20)

        # Lancer le système de fermeture automatique des rideaux
        self.lancer_fermeture_automatique_rideaux()

    # Mise à jour continue de l'heure
    def mettre_a_jour_heure(self):
        now = datetime.datetime.now()  # Heure actuelle
        self.label_heure.config(text=f"Heure actuelle : {now.strftime('%H:%M:%S')}")
        self.root.after(1000, self.mettre_a_jour_heure)  # Répéter chaque seconde

    # Éteindre toutes les pièces et réinitialiser la température
    def tout_eteindre(self):
        for piece in self.objets_pieces:
            piece.eteindre_tout()
        messagebox.showinfo("Action globale", "Toutes les lumières ont été éteintes et les températures réinitialisées.")

    # Affiche un résumé de l'état de chaque pièce
    def afficher_etat(self):
        etats = []
        for piece in self.objets_pieces:
            etats.append(f"{piece.nom} → {piece.etat_lumiere.get()} / Température : {piece.scale_temp.get()}°C")
        messagebox.showinfo("État général de la maison", "\n".join(etats))

    # Simule une alarme en cas d'intrusion
    def declencher_alarme_intrus(self):
        messagebox.showwarning("ALERTE", "🚨 Intrus détecté ! Déclenchement de l'alarme de sécurité !")

    # Simule une alarme incendie
    def declencher_alarme_incendie(self):
        messagebox.showerror("INCENDIE", "🔥 Alerte incendie détectée ! Alerte envoyée aux pompiers !")

    # Simule l'activation d'une smart TV
    def smart_tv(self):
        messagebox.showinfo("Smart TV", "📺 Smart TV du Salon allumée. Lecture de votre playlist Netflix.")

    # Ferme automatiquement les rideaux à 19h
    def lancer_fermeture_automatique_rideaux(self):
        def verifier_heure():
            while True:
                now = datetime.datetime.now()
                if now.hour == 19 and now.minute == 0:
                    messagebox.showinfo("Rideaux", "🕖 Il est 19h. Fermeture automatique des rideaux.")
                    break
                time.sleep(60)  # Vérifie toutes les 60 secondes

        thread = threading.Thread(target=verifier_heure, daemon=True)  # Thread pour ne pas bloquer l'interface
        thread.start()

# Lancement de l'application
if __name__ == "__main__":
    fenetre = Tk()  # Crée la fenêtre principale
    app = ApplicationDomotique(fenetre)  # Instancie l'application
    fenetre.mainloop()  # Lance la boucle principale Tkinter